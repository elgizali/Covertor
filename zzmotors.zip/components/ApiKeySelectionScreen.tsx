
import React, { useState } from 'react';
import { KeyIcon, SaveIcon } from './Icons';

interface ApiKeySelectionScreenProps {
    onKeySubmit: (apiKey: string) => void;
    error?: string | null;
}

export const ApiKeySelectionScreen: React.FC<ApiKeySelectionScreenProps> = ({ onKeySubmit, error }) => {
    const [localApiKey, setLocalApiKey] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (localApiKey.trim()) {
            onKeySubmit(localApiKey.trim());
        }
    };

    return (
        <div className="min-h-screen bg-transparent text-gray-100 flex flex-col items-center justify-center p-4">
            <div className="w-full max-w-md">
                 <header className="text-center mb-8">
                    <div className="flex justify-center items-center mb-4">
                        <h1 className="text-4xl sm:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-600" style={{ textShadow: '0 0 10px rgba(0, 255, 255, 0.3)' }}>
                            ZZMOTORS
                        </h1>
                    </div>
                     <p className="text-gray-400">Başlamazdan əvvəl, lütfən, Google AI Studio API açarınızı daxil edin.</p>
                </header>

                <main className="bg-gray-900/50 backdrop-blur-md border border-cyan-500/20 rounded-xl shadow-2xl shadow-cyan-500/10 p-8 space-y-6">
                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div>
                             <label htmlFor="api-key" className="block text-sm font-medium text-cyan-200 mb-2">
                                Gemini API Açarınız
                            </label>
                            <div className="relative">
                                <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                                    <KeyIcon className="h-5 w-5 text-gray-400" />
                                </span>
                                <input
                                    id="api-key"
                                    type="password"
                                    value={localApiKey}
                                    onChange={(e) => setLocalApiKey(e.target.value)}
                                    placeholder="API açarını buraya daxil edin"
                                    className="block w-full pl-10 pr-3 py-2 bg-gray-900/70 border border-cyan-700/50 rounded-md placeholder-gray-500 text-gray-200 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition"
                                    required
                                    aria-label="Gemini API Açarınız"
                                />
                            </div>
                        </div>
                         {error && (
                            <p className="text-sm text-red-400 text-center" role="alert">{error}</p>
                        )}
                        <button
                            type="submit"
                            disabled={!localApiKey.trim()}
                            className="w-full inline-flex items-center justify-center px-4 py-2 border border-transparent font-medium rounded-lg text-white bg-cyan-600 hover:bg-cyan-500 disabled:bg-cyan-900/50 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-cyan-500 transition-all transform hover:scale-105"
                        >
                            <SaveIcon className="w-5 h-5 mr-2"/>
                            Açarı Yadda Saxla
                        </button>
                    </form>
                </main>
                 <footer className="fixed bottom-4 left-4 z-50">
                    <p className="text-xs font-medium tracking-wider uppercase text-gray-500 transition-colors hover:text-cyan-400">
                        ELGIZ ALIYEV
                    </p>
                </footer>
            </div>
        </div>
    );
};
