
import React, { useRef, useState } from 'react';
// Fix: Imported CameraIcon to be used for the new camera button.
import { UploadIcon, CameraIcon } from './Icons';

interface FileUploadProps {
    onFileSelect: (file: File | null) => void;
    // Fix: Added onCameraOpen to the props interface to resolve the type error.
    onCameraOpen: () => void;
}

export const FileUpload: React.FC<FileUploadProps> = ({ onFileSelect, onCameraOpen }) => {
    const inputRef = useRef<HTMLInputElement>(null);
    const [dragging, setDragging] = useState(false);

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0] || null;
        onFileSelect(file);
    };

    const handleDragEnter = (e: React.DragEvent<HTMLLabelElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setDragging(true);
    };

    const handleDragLeave = (e: React.DragEvent<HTMLLabelElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setDragging(false);
    };

    const handleDragOver = (e: React.DragEvent<HTMLLabelElement>) => {
        e.preventDefault();
        e.stopPropagation();
    };

    const handleDrop = (e: React.DragEvent<HTMLLabelElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setDragging(false);
        const file = e.dataTransfer.files?.[0] || null;
        onFileSelect(file);
        if (inputRef.current) {
          inputRef.current.files = e.dataTransfer.files;
        }
    };
    
    return (
        // Fix: Wrapped the component in a div to logically group the dropzone and the new camera button.
        <div className="w-full">
            <label
                onDragEnter={handleDragEnter}
                onDragLeave={handleDragLeave}
                onDragOver={handleDragOver}
                onDrop={handleDrop}
                className={`flex flex-col items-center justify-center w-full h-64 border-2 border-dashed rounded-lg cursor-pointer transition-colors duration-300 ${
                    dragging ? 'border-cyan-400 bg-cyan-900/30' : 'border-cyan-800/50 bg-black/30 hover:bg-cyan-900/20 hover:border-cyan-700'
                }`}
            >
                <div className="flex flex-col items-center justify-center text-center p-4">
                    <UploadIcon className="w-10 h-10 mb-3 text-gray-400" />
                    <p className="mb-2 text-sm text-gray-300">
                        Sənədi printerdə skan edin
                    </p>
                    <p className="mb-2 text-sm text-gray-400">
                        <span className="font-semibold text-cyan-400">Yükləmək üçün klikləyin</span> və ya şəkli sürüşdürüb buraxın
                    </p>
                    <p className="text-xs text-gray-500">Yalnız JPEG və ya PNG formatları dəstəklənir</p>
                </div>
                <input
                    ref={inputRef}
                    type="file"
                    className="hidden"
                    accept="image/jpeg,image/png"
                    onChange={handleFileChange}
                />
            </label>
            
            <div className="flex items-center w-full my-4">
                <div className="flex-grow border-t border-cyan-800/50"></div>
                <span className="flex-shrink mx-4 text-gray-400 text-sm">və ya</span>
                <div className="flex-grow border-t border-cyan-800/50"></div>
            </div>

            <button
                onClick={(e) => { e.preventDefault(); onCameraOpen(); }}
                className="w-full inline-flex items-center justify-center px-4 py-3 border border-cyan-700/50 font-medium rounded-lg text-cyan-200 bg-black/30 hover:bg-cyan-900/20 hover:border-cyan-700 transition-colors"
            >
                <CameraIcon className="w-5 h-5 mr-2" />
                Kamera ilə Skan Et
            </button>
        </div>
    );
};
