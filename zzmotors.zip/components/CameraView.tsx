import React, { useRef, useEffect, useState, useCallback } from 'react';

interface CameraViewProps {
    onCapture: (file: File) => void;
    onClose: () => void;
}

export const CameraView: React.FC<CameraViewProps> = ({ onCapture, onClose }) => {
    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const [error, setError] = useState<string | null>(null);
    const [stream, setStream] = useState<MediaStream | null>(null);

    useEffect(() => {
        let activeStream: MediaStream | null = null;
        
        const startCamera = async () => {
            try {
                activeStream = await navigator.mediaDevices.getUserMedia({ 
                    video: { facingMode: 'environment' } 
                });
                setStream(activeStream);
                if (videoRef.current) {
                    videoRef.current.srcObject = activeStream;
                }
            } catch (err) {
                console.error("Kamera xətası:", err);
                let message = "Kameraya daxil olmaq mümkün olmadı. Zəhmət olmasa, səhifəni yeniləyin və ya başqa brauzer ilə cəhd edin.";
                if (err instanceof DOMException && (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError')) {
                    message = "Kameraya giriş üçün icazə tələb olunur. Zəhmət olmasa, səhifəni yeniləyib icazə sorğusunu qəbul edin və ya brauzerinizin parametrlərindən bu sayt üçün kameraya girişi aktivləşdirin.";
                }
                setError(message);
            }
        };

        startCamera();

        return () => {
            if (activeStream) {
                activeStream.getTracks().forEach(track => track.stop());
            }
        };
    }, []);

    const handleCapture = useCallback(() => {
        if (videoRef.current && canvasRef.current) {
            const video = videoRef.current;
            const canvas = canvasRef.current;
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            const context = canvas.getContext('2d');
            if (context) {
                context.drawImage(video, 0, 0, canvas.width, canvas.height);
                canvas.toBlob((blob) => {
                    if (blob) {
                        const file = new File([blob], `scan-${Date.now()}.jpg`, { type: 'image/jpeg' });
                        onCapture(file);
                    }
                }, 'image/jpeg', 0.95);
            }
        }
    }, [onCapture]);

    return (
        <div className="fixed inset-0 bg-gray-900 z-50 flex flex-col items-center justify-center">
            <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover"></video>
            <canvas ref={canvasRef} className="hidden"></canvas>
            
            {error && (
                <div className="absolute top-4 left-4 right-4 p-4 bg-red-900/80 border border-red-500 text-white rounded-lg text-center">
                    {error}
                </div>
            )}
            
            <div className="absolute bottom-0 left-0 right-0 p-8 bg-gradient-to-t from-black/80 to-transparent flex justify-center items-center">
                <button
                    onClick={handleCapture}
                    disabled={!!error}
                    aria-label="Şəkil çək"
                    className="w-20 h-20 rounded-full bg-white/90 ring-4 ring-white/50 ring-offset-4 ring-offset-black/50 hover:bg-white disabled:bg-gray-500 disabled:opacity-50 transition transform hover:scale-110 focus:outline-none"
                >
                </button>
            </div>
            
            <button
                onClick={onClose}
                aria-label="Kameranı bağla"
                className="absolute top-6 right-6 w-12 h-12 rounded-full bg-black/50 text-white hover:bg-black/80 flex items-center justify-center transition"
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>
    );
};
