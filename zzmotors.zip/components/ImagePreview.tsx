import React from 'react';

interface ImagePreviewProps {
    src: string;
}

export const ImagePreview: React.FC<ImagePreviewProps> = ({ src }) => {
    return (
        <div className="mt-4 w-full">
            <h3 className="text-lg font-medium text-gray-300 mb-2">Şəklin önizləməsi:</h3>
            <div className="w-full h-64 overflow-hidden rounded-lg border border-cyan-800/50 flex items-center justify-center bg-black/50 p-1">
                <img src={src} alt="Uploaded table" className="max-w-full max-h-full object-contain rounded-md" />
            </div>
        </div>
    );
};