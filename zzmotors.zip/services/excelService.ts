// This service assumes the global ExcelJS object is available from the CDN script in index.html
declare var ExcelJS: any;

const saveAs = (blob: Blob, fileName: string) => {
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(link.href);
};

export const generateExcelFile = async (data: string[][], fileName: string): Promise<void> => {
    try {
        if (!ExcelJS) {
            throw new Error("ExcelJS library is not loaded.");
        }

        const workbook = new ExcelJS.Workbook();
        const worksheet = workbook.addWorksheet('Məlumatlar');
        
        // Add data to worksheet
        worksheet.addRows(data);

        // Find the index of the 'Code' column from the header row
        if (data.length > 0) {
            const headers = data[0];
            const codeColumnIndex = headers.findIndex(header => header.trim().toLowerCase() === 'code');
            
            // If the 'Code' column is found, set its number format to Text ('@')
            // This prevents Excel from interpreting numeric codes as numbers and stripping leading zeros.
            if (codeColumnIndex !== -1) {
                // getColumn is 1-based, so we add 1 to the index
                const codeColumn = worksheet.getColumn(codeColumnIndex + 1);
                codeColumn.numFmt = '@';
            }
        }

        // Style header row for better distinction
        const headerRow = worksheet.getRow(1);
        headerRow.height = 25; // Set a custom height for the header
        headerRow.eachCell((cell) => {
            cell.fill = {
                type: 'pattern',
                pattern: 'solid',
                fgColor: { argb: 'FF004A7F' } // A distinct, dark blue
            };
            cell.font = {
                bold: true,
                color: { argb: 'FFFFFFFF' }, // White text for contrast
                size: 12
            };
            cell.alignment = {
                vertical: 'middle',
                horizontal: 'center'
            };
            cell.border = {
                bottom: { style: 'thin', color: { argb: 'FFDDDDDD' } }
            };
        });


        // Auto-fit columns based on content length
        worksheet.columns.forEach(column => {
            let maxLength = 0;
            column.eachCell!({ includeEmpty: true }, cell => {
                const columnLength = cell.value ? cell.value.toString().length : 0;
                if (columnLength > maxLength) {
                    maxLength = columnLength;
                }
            });
            // Set a minimum width and add padding for better readability
            column.width = maxLength < 12 ? 12 : maxLength + 4;
        });
        
        // Generate and download the file
        const buffer = await workbook.xlsx.writeBuffer();
        const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        saveAs(blob, fileName);

    } catch (error) {
        console.error("Error generating Excel file with ExcelJS:", error);
        const message = error instanceof Error ? error.message : "Bilinməyən xəta baş verdi";
        throw new Error(`Excel faylı yaradıla bilmədi. Xəta: ${message}`);
    }
};