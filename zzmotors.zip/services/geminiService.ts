
import { GoogleGenAI, Type } from "@google/genai";

const model = 'gemini-2.5-flash';

export const convertImageToTableData = async (base64Image: string, mimeType: string, apiKey: string): Promise<string[][]> => {
    const ai = new GoogleGenAI({ apiKey });

    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: {
                parts: [
                    {
                        inlineData: {
                            mimeType,
                            data: base64Image,
                        },
                    },
                    {
                        text: "You are an expert AI for extracting and structuring data from automotive parts documents. Your goal is to convert the data from the provided image into a precise JSON format with a specific structure.\n\n**Final Table Structure & Rules:**\nConvert the extracted data to match this exact column order and apply these rules:\n1.  `Code` (from `HİSSƏ KODU`): **CRITICAL - MAXIMUM ACCURACY.** Correct all OCR errors. Common mistakes are 'O'/'0', 'I'/'1', 'S'/'5', 'B'/'8', and especially 'H'/'4'.\n2.  `Brend` (New Column): Identify the brand (e.g., VAG, BMW, Mercedes) from the `Code` column and place it here. If unsure, leave it blank.\n3.  `Description` (from `TƏSVİR`): Translate any English text to Azerbaijani.\n4.  `Sayı` (from `KƏMİYYƏT`): The quantity of the item.\n5.  `ƏDV-siz` (from `XALİ QİYMƏT`): **This must be the UNIT PRICE**, not the total line price. Remove all currency symbols, keeping only the number.\n6.  `CƏMİ` (New Column): **Calculate this value.** Multiply the number from the `Sayı` column by the number from the `ƏDV-siz` (unit price) column. The result should be a number.\n7.  `Alış Tarixi` (New, empty column)\n8.  `Companiyanin adı` (New, empty column)\n9.  `EGB` (New, empty column)\n10. `INVOICE` (New, empty column)\n\n**Important:**\n*   Discard original columns named 'LC', 'CN', 'ŞƏRH'.\n*   The final output must be ONLY the raw JSON array of arrays. It must start with `[` and end with `]`. The first inner array must be the headers listed above, in the correct order.",
                    },
                ],
            },
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.STRING,
                        },
                    },
                },
            },
        });
        
        const jsonText = response.text?.trim();

        if (!jsonText) {
            throw new Error("AI cavabı boşdur. Bu, təhlükəsizlik filtrləri və ya aydın olmayan şəkil səbəbindən ola bilər.");
        }

        try {
            const parsedData = JSON.parse(jsonText);
            if (!Array.isArray(parsedData) || !parsedData.every(row => Array.isArray(row))) {
                console.error("API returned data in an unexpected format:", parsedData);
                throw new Error("AI cavabı gözlənilən cədvəl formatında deyil.");
            }
            return parsedData;
        } catch (parseError) {
             console.error("Failed to parse JSON from model response:", parseError, "Original text:", jsonText);
             throw new Error("AI cavabı etibarlı JSON formatında deyil. Zəhmət olmasa, daha aydın bir şəkil ilə yenidən cəhd edin.");
        }

    } catch (error) {
        console.error("Error calling Gemini API:", error);
        // Re-throw the original error so the caller (App.tsx) can inspect its message for specific keywords like 'API key not valid'.
        if (error instanceof Error) {
            throw error;
        }
        throw new Error("Şəkil çevrilərkən bilinməyən bir API xətası baş verdi.");
    }
};
